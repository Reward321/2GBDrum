2GBDrum
=======

Folder structure:

2gbdrum/
├── index.html
├── style.css
├── app.js
├── sw.js
└── sounds/
    ├── tom.wav
    ├── rom.wav
    ├── crash.wav
    ├── bell.wav
    ├── kick.wav
    ├── snare.wav
    ├── closed-hihat.wav
    └── open-hihat.wav

IMPORTANT:
Put your actual drum WAV files inside the sounds folder using exactly
the filenames above.

OFFLINE:
The service worker caches the HTML/CSS/JS and all eight sound files.
After the first successful online visit, the browser can serve them
from its local cache without downloading them again.

Service workers require HTTPS on a real website. GitHub Pages, Vercel,
Netlify and similar HTTPS hosting work. localhost also works for testing.

If you change a sound or code later, increase CACHE_NAME in sw.js:
2gbdrum-v1 -> 2gbdrum-v2

That tells the browser to install a fresh cache.

TESTING:
1. Open the site once while online.
2. Tap every pad once.
3. Refresh.
4. Turn off Wi-Fi/mobile data.
5. Open the same site again.
6. The cached app and sounds should still work.

Note: browser storage is persistent but not an absolute permanent
guarantee. A browser/user can clear site data, and storage can be
evicted in some circumstances.
