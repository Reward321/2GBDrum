const pads = document.querySelectorAll(".pad");

const sounds = {
  tom: "sounds/tom.wav",
  rom: "sounds/rom.wav",
  crash: "sounds/crash.wav",
  bell: "sounds/bell.wav",
  kick: "sounds/kick.wav",
  snare: "sounds/snare.wav",
  "closed-hihat": "sounds/closed-hihat.wav",
  "open-hihat": "sounds/open-hihat.wav"
};

// Create the audio objects once.
// The browser can then reuse them instead of creating a new one every hit.
const audio = {};

for (const name in sounds) {
  audio[name] = new Audio(sounds[name]);
  audio[name].preload = "auto";
}

function playSound(name, pad) {
  const sound = audio[name];

  if (!sound) return;

  // Reset the sound so fast repeated hits work.
  sound.currentTime = 0;
  sound.play();

  pad.classList.add("active");

  setTimeout(() => {
    pad.classList.remove("active");
  }, 80);
}

pads.forEach((pad) => {
  pad.addEventListener("pointerdown", () => {
    playSound(pad.dataset.sound, pad);
  });
});

document.addEventListener("keydown", (event) => {
  if (event.repeat) return;

  const pad = document.querySelector(
    `.pad[data-key="${event.key}"]`
  );

  if (!pad) return;

  playSound(pad.dataset.sound, pad);
});

// Register the offline service worker.
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js")
    .then(() => console.log("2GBDrum offline cache ready"))
    .catch((error) => console.log("Service worker error:", error));
}
